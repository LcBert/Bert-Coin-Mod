package net.mcreator.bertcoinmod.procedures;

import net.neoforged.neoforge.items.ItemHandlerHelper;
import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.bertcoinmod.network.BertCoinModModVariables;
import net.mcreator.bertcoinmod.init.BertCoinModModItems;

public class WalletProcedureProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		double coins_count = 0;
		if (!entity.isShiftKeyDown()) {
			coins_count = 0;
			if (entity.getCapability(Capabilities.ItemHandler.ENTITY, null) instanceof IItemHandlerModifiable _modHandlerForEach) {
				for (int _idx = 0; _idx < _modHandlerForEach.getSlots(); _idx++) {
					ItemStack itemstackiterator = _modHandlerForEach.getStackInSlot(_idx).copy();
					if (BertCoinModModItems.COIN.get() == itemstackiterator.getItem()) {
						coins_count = coins_count + itemstackiterator.getCount();
					}
				}
			}
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(BertCoinModModItems.COIN.get());
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) coins_count, _player.inventoryMenu.getCraftSlots());
			}
			{
				BertCoinModModVariables.PlayerVariables _vars = entity.getData(BertCoinModModVariables.PLAYER_VARIABLES);
				_vars.Coins = entity.getData(BertCoinModModVariables.PLAYER_VARIABLES).Coins + coins_count;
				_vars.syncPlayerVariables(entity);
			}
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(("" + entity.getData(BertCoinModModVariables.PLAYER_VARIABLES).Coins)), true);
		} else {
			if (entity.getData(BertCoinModModVariables.PLAYER_VARIABLES).Coins < 64) {
				if (entity instanceof Player _player) {
					ItemStack _setstack = new ItemStack(BertCoinModModItems.COIN.get()).copy();
					_setstack.setCount((int) entity.getData(BertCoinModModVariables.PLAYER_VARIABLES).Coins);
					ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
				}
				{
					BertCoinModModVariables.PlayerVariables _vars = entity.getData(BertCoinModModVariables.PLAYER_VARIABLES);
					_vars.Coins = 0;
					_vars.syncPlayerVariables(entity);
				}
			} else {
				if (entity instanceof Player _player) {
					ItemStack _setstack = new ItemStack(BertCoinModModItems.COIN.get()).copy();
					_setstack.setCount(64);
					ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
				}
				{
					BertCoinModModVariables.PlayerVariables _vars = entity.getData(BertCoinModModVariables.PLAYER_VARIABLES);
					_vars.Coins = entity.getData(BertCoinModModVariables.PLAYER_VARIABLES).Coins - 64;
					_vars.syncPlayerVariables(entity);
				}
			}
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(("" + entity.getData(BertCoinModModVariables.PLAYER_VARIABLES).Coins)), true);
		}
	}
}
